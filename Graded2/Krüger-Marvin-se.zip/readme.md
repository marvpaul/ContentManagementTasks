# Crawler
Der Crawler liegt in crawler, spiders, Spider.py
Ausgeführt wird er wie folgt: 
- Wechseln in das Verzeichnis crawler
- Ausführen von: scrapy crawl crawler

